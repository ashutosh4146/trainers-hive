# Trainers Hive

## Overview

Trainers Hive is a B2B training marketplace connecting companies, colleges, and institutes with verified trainers. The platform streamlines the process of posting training requirements, managing applications, and facilitating trainer hiring. Its primary goal is to become the leading hub for professional training procurement and delivery, enhancing efficiency and quality in corporate and institutional learning and development.

## User Preferences

- I prefer simple language.
- I like iterative development.
- Ask before making major changes.
- I prefer detailed explanations.
- Do not make changes to the folder `lib/api-spec`.
- Do not make changes to the folder `lib/api-zod`.
- Do not make changes to the folder `lib/api-client-react`.
- Do not make changes to the folder `lib/db`.
- Do not make changes to the folder `lib/object-storage-web`.
- Do not make changes to the file `openapi.yaml`.
- Do not make changes to the file `src/validators.ts` in `lib/api-zod`.
- Do not make changes to the folder `artifacts/mockup-sandbox`.
- Ensure all frontend imports for generated hooks are exclusively from `@workspace/api-client-react`.
- For one-off authenticated `fetch` calls outside generated hooks, use `customFetch` from `@workspace/api-client-react` to automatically attach the `Authorization: Bearer` token.
- Avoid raw `fetch()` for authenticated endpoints.
- After mutations, always invalidate the matching `getXxxQueryKey(...)` query.
- Use `lucide-react` icons instead of emojis in the UI.

## System Architecture

The project is structured as a pnpm monorepo.

**Frontend:**
-   **Frameworks:** React with Vite and TypeScript.
-   **Routing:** Wouter.
-   **State Management/Data Fetching:** TanStack Query.
-   **Styling:** Tailwind CSS v4 with shadcn/ui components.
-   **Animations:** Framer Motion.
-   **Charting:** Recharts.
-   **Theme:** `next-themes` `ThemeProvider` for light/dark/system mode, integrated with Tailwind CSS dark mode via `attribute="class"` on `<html>`.

**Backend:**
-   **Framework:** Express.js.
-   **ORM:** Drizzle ORM.
-   **API Design:** OpenAPI-driven (contract-first approach).
-   **Authentication:** Self-signed JWT for password logins (stored in `localStorage`), supplemented by Firebase Email Link for passwordless sign-in.
-   **User Roles:** `trainer`, `vendor`, `admin`. `vendor` role encompasses `corporate`, `college`, `educational` via `orgType`.
-   **Session Management:** `GET /api/session` serves as the source of truth for user display.

**Shared Libraries:**
-   `api-spec`: OpenAPI definitions.
-   `api-zod`: Generated Zod schemas for validation.
-   `api-client-react`: Generated React Query hooks for API interaction.
-   `db`: Drizzle ORM schema definitions.
-   `object-storage-web`: Browser-based object upload utilities.

**Database:**
-   PostgreSQL.
-   Key entities include `trainers`, `requirements`, `applications`, `vendors`, `users`, `verification_requests`, `endorsements`, `saved_trainers`, `application_messages`, `hire_inquiries`, and `activities`.
-   Uses `jsonb` for flexible data structures like `subSkills`, `languages`, `certifications`, and `engagedDates`.

**Core Features:**
-   **Vendor Workflow:** Multi-step requirement posting, application management (shortlist, hire, reject), training completion, review submission, trainer saving, and time-to-hire tracking.
-   **Trainer Workflow:** Requirement browsing, application submission with rate proposals, status tracking, and withdrawal. Comprehensive profile management (skills, experience, location, certifications, resume, bio, trainer type), verification application, and engaged date management.
-   **Endorsements:** Vendors can endorse trainers post-engagement, visible on trainer profiles and manageable from their dashboard.
-   **Admin Features:** Centralized dashboard for platform statistics, user and requirement management, vendor verification, CSV exports, and growth analytics.
-   **Messaging:** In-app messaging for shortlisted/hired applications with unread notifications.
-   **Requirement Management:** Trainers can flag requirements; vendors can extend application deadlines. Real-time search and status filtering for applications.
-   **New Requirement Form:** Detailed multi-step form including city/state autocomplete (Indian data), timeline management, and training mode selection.
-   **Skill Filtering:** Multi-select skill filter component across trainer and requirement listings with backend `OR`-matching support.

**UI/UX:**
-   **Components:** Custom components like `SuggestionInput`, `SkillCombobox`, `TagInput`, `CertificationsEditor`, `AdminRemoveButton`, `MessageThread`, and a dedicated `Messages` page.
-   **Conventions:** Trainer ratings are numeric. Only `lucide-react` icons are used.

## External Dependencies

-   **Authentication Services:** Firebase (for email links and admin SDK).
-   **AI Services:** OpenAI `gpt-4o-mini` (via Replit proxy for trainer-requirement matching).
-   **Charting Library:** Recharts (for admin analytics).
-   **Icon Library:** Lucide React.

## Environment Variables

-   **`APP_DOMAIN`**: The production domain (e.g. `trainershive.com`). Used by the API server to build absolute URLs in outgoing emails (unsubscribe links, trainer profile links, requirement links). Previously referenced as `REPLIT_DOMAINS` — replaced with `APP_DOMAIN` to make the app hosting-platform agnostic.